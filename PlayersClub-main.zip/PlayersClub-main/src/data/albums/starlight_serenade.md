---
name: 'Starlight Serenade'
image:
  src: '/images/albums/starlight_serenade.webp'
  alt: 'A dreamy night sky with twinkling stars, cherry blossoms illuminated by fairy lights, and a soft glow from the horizon, evoking magic and peace.'
publishDate: 2026-09-15
tracks:
  - 'Celestial Dance'
  - 'Starlight Serenade'
  - 'Wishes on the Wind'
  - 'Eternal Night'
  - 'Radiant Sky'
  - 'Aurora Chime'
  - 'Glittering Petals'
  - 'Midnight Glow'
  - 'Shooting Stars'
  - 'Echoes of the Moon'
artist: 'hoilin'
---

**Starlight Serenade** is Hoilin’s magical third album, featuring uplifting J-Pop melodies and dreamy visuals. This album encapsulates the wonder of a starlit sky and the joy of endless possibilities.
