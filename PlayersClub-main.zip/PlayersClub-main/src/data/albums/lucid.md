---
name: 'Lucid'
image:
  src: '/images/albums/lucid.webp'
  alt: 'An abstract album art design featuring gradients of pale yellow and silver with smooth, flowing waves and subtle shimmering textures.'
publishDate: 2025-05-15
tracks:
  - 'Lucid'
  - 'Golden Reverie'
  - 'Weightless Moments'
  - 'Waves of Silence'
  - 'Faint Horizon'
  - 'Light Through the Fog'
  - 'Invisible Threads'
  - 'Dreamcatcher'
  - 'Nocturnal Visions'
  - 'Endless Glow'
artist: 'wale'
---

**Lucid** is Wale’s introspective sophomore album, blending serene soundscapes with heartfelt lyrics. This record expands on his dream pop style, drawing listeners into its radiant and tranquil world.
