---
name: 'Concrete Verses'
image:
  src: '/images/albums/concrete_verses.webp'
  alt: "A gritty urban skyline with stylized graffiti text, a microphone embedded in the concrete, and vibrant pops of red and yellow, featuring mia-sue's 'MS' logo prominently at the top."
publishDate: 2026-01-30
tracks:
  - 'Concrete Verses'
  - 'Echoes of Strength'
  - 'The Underdog'
  - 'Fire on the Pavement'
  - 'Graffiti Anthem'
  - 'Legacy Written in Stone'
  - 'LA Rhythms'
  - 'Resilience Rising'
  - 'Microphone Justice'
  - 'Unbreakable Flow'
artist: 'mia-sue'
---

**Concrete Verses** is Mia Sue’s hard-hitting sophomore album, combining gritty beats with empowering lyrics. This album showcases her growth as an artist and continues to celebrate the resilience and energy of her community.
