---
name: 'Electric Velvet'
image:
  src: '/images/albums/electric_velvet.webp'
  alt: 'A vibrant abstract design with electric blue and neon pink waves blending like velvet on a dark, pulsating background, evoking energy and edginess.'
publishDate: 2024-08-10
tracks:
  - 'Pulse'
  - 'Electric Velvet'
  - 'Neon Fever'
  - 'Break the Lights'
  - 'Synthetic Desire'
  - 'Glitter and Smoke'
  - 'Velocity'
  - 'Night Strobe'
  - 'Friction'
  - 'Burn Bright'
artist: 'harlxn'
---

**Electric Velvet** is HARLXN’s explosive debut album, packed with high-energy beats and sharp, rebellious lyrics. With addictive hooks and a bold sound, this album is a celebration of individuality and empowerment, cementing HARLXN as a rising star in electro-pop.
