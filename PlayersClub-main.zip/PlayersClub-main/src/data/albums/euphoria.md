---
name: 'Euphoria'
image:
  src: '/images/albums/euphoria.webp'
  alt: 'A vibrant city skyline at night glowing with neon lights in pink, blue, and purple, with a silhouette of a confident figure looking out, evoking empowerment and dynamism.'
publishDate: 2024-06-10
tracks:
  - 'Neon Rush'
  - 'Euphoria'
  - 'Electric Pulse'
  - 'Freefall'
  - 'City of Lights'
  - 'Edge of Desire'
  - 'Crystal Horizon'
  - 'Fever Dream'
  - 'Shimmering Nights'
  - 'Nova Rising'
artist: 'isla-nova'
---

**Euphoria** is Isla Nova’s breakout debut album, bursting with retro synths and bold energy. With infectious beats and empowering lyrics, this record captures the thrill of self-discovery and the rush of living unapologetically.
