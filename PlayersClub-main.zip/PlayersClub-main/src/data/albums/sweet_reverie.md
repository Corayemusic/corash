---
name: 'Sweet Reverie'
image:
  src: '/images/albums/sweet_reverie.webp'
  alt: 'A pastel-colored park in springtime with blooming cherry blossoms, soft pink skies, and a vintage-style swing, evoking a playful and dreamy J-Pop mood.'
publishDate: 2024-04-15
tracks:
  - 'Cherry Blossom Dreams'
  - 'Sweet Reverie'
  - 'Pastel Skies'
  - 'Wings of Joy'
  - 'Whimsical World'
  - 'Rainbow Confetti'
  - 'Daylight Sparkles'
  - 'Starry-eyed Summer'
  - 'Kaleidoscope Love'
  - 'Morning Glow'
artist: 'hoilin'
---

**Sweet Reverie** is Hoilin’s delightful debut album, filled with catchy J-Pop melodies and whimsical charm. This album brings joy and positivity, capturing the essence of fleeting moments of beauty and playfulness.
