---
name: 'Starlight Fever'
image:
  src: '/images/albums/starlight_fever.webp'
  alt: 'A shimmering disco ball glowing under vibrant pink and gold lights, surrounded by subtle star patterns.'
publishDate: 2024-10-10
tracks:
  - 'Starlight Fever'
  - 'Velvet Groove'
  - 'Golden Nights'
  - 'Dancing Through Time'
  - 'Euphoria Lights'
  - 'Neon Pulse'
  - 'Mirrorball Dreams'
  - 'Liberation Anthem'
  - 'Midnight Glow'
  - 'Final Sparkle'
artist: 'luna-deluxe'
---

**Starlight Fever** is Luna Deluxe’s radiant debut album, blending retro disco vibes with modern pop sensibilities. Bursting with infectious grooves and empowering lyrics, this album lights up dancefloors with its shimmering energy and glamour.
