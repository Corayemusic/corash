---
name: 'Rebellion'
image:
  src: '/images/albums/rebellion.webp'
  alt: 'An abstract album art design featuring a single bold red color with dynamic streaks and shapes resembling lightning and flames, symbolizing energy and defiance.'
publishDate: 2024-10-05
tracks:
  - 'Rebellion'
  - 'Flames of Freedom'
  - 'Electric Hearts'
  - 'Through the Crimson Light'
  - 'Rise of the Underdogs'
  - 'Starlit Chaos'
  - 'Burning Bright'
  - 'Crimson Serenade'
  - 'Eclipse of the Crown'
  - 'Final Spark'
artist: 'stardust-royale'
---

**Rebellion** is Stardust Royale’s electrifying debut album, capturing the energy and extravagance of glam rock. With soaring anthems and powerful lyrics, this album celebrates individuality and freedom in its most vibrant form.
